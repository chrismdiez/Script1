$(document).ready(function () {

    ZOHO.CREATOR.init()
        .then(function (data) {
            //Code goes here
        });




});

